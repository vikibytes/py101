# Human_Resources_Analytics

Well, while I was searching in [kaggle](https://www.kaggle.com) for my new project, I found this interesting dataset! The title was attractive and in a further exploration, it was and the content too. All we got is a data frame​ with 10 attributes. Nine(9) of them are indicative for why employees leaving prematurely their companies.  Let's see in deeper analysis our problem...


We have to predict if the employee will either stay or leave the company. So this is a classification (supervised learning) problem. To be more clear it's a discrete value estimation (Binary values like 0/1, yes/no, True/False).

To classify class labels I used Decision trees and specifically Random Forests! Finally I compare my results and accuracy with Logistic’s Regression results which is a binary classification algorithm as well.

skills acquired & tools :Random Forests, Pandas, Numpy, Sci-kit Learn, Matplotlib, Seaborn